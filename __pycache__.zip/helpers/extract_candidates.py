from nltk.tokenize import word_tokenize
from nltk.parse import CoreNLPParser

# Load the Stanford Parser from NLTK
parser = CoreNLPParser(url='http://localhost:5000')

def extract_candidates(narrative):
    # Tokenize the narrative into words
    tokens = word_tokenize(narrative)

    # Parse the sentence to extract the candidate classes, attributes, and operations
    parse_tree = next(parser.parse(tokens))
    candidate_classes = []
    candidate_attributes = []
    candidate_operations = []

    for subtree in parse_tree.subtrees():
        if subtree.label() == 'NP': # Identify noun phrases as potential candidate classes
            candidate_classes.append(subtree.leaves())
        elif subtree.label() == 'VP': # Identify verb phrases as potential candidate operations
            candidate_operations.append(subtree.leaves())
        elif subtree.label() == 'JJ': # Identify adjectives as potential candidate attributes
            candidate_attributes.append(subtree.leaves())

    # Return the extracted candidate classes, attributes, and operations
    return candidate_classes, candidate_attributes, candidate_operations
