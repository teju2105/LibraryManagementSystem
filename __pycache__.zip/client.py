import requests

url = 'http://localhost:5000/extract'
data = {'narrative': 'The library management system allows users to borrow books, reserve books, and return books.'}
response = requests.post(url, json=data)

print(response.json())
